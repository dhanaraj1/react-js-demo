/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.7.17-log : Database - reactdemonew
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`reactdemonew` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `reactdemonew`;

/*Table structure for table `tbl_company` */

DROP TABLE IF EXISTS `tbl_company`;

CREATE TABLE `tbl_company` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `tbl_company` */

insert  into `tbl_company`(`company_id`,`company_name`) values (1,'Techforce Infotech');

/*Table structure for table `tbl_country` */

DROP TABLE IF EXISTS `tbl_country`;

CREATE TABLE `tbl_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;

/*Data for the table `tbl_country` */

insert  into `tbl_country`(`id`,`country_code`,`country_name`) values (1,'AF','Afghanistan'),(2,'AL','Albania'),(3,'DZ','Algeria'),(4,'DS','American Samoa'),(5,'AD','Andorra'),(6,'AO','Angola'),(7,'AI','Anguilla'),(8,'AQ','Antarctica'),(9,'AG','Antigua and Barbuda'),(10,'AR','Argentina'),(11,'AM','Armenia'),(12,'AW','Aruba'),(13,'AU','Australia'),(14,'AT','Austria'),(15,'AZ','Azerbaijan'),(16,'BS','Bahamas'),(17,'BH','Bahrain'),(18,'BD','Bangladesh'),(19,'BB','Barbados'),(20,'BY','Belarus'),(21,'BE','Belgium'),(22,'BZ','Belize'),(23,'BJ','Benin'),(24,'BM','Bermuda'),(25,'BT','Bhutan'),(26,'BO','Bolivia'),(27,'BA','Bosnia and Herzegovina'),(28,'BW','Botswana'),(29,'BV','Bouvet Island'),(30,'BR','Brazil'),(31,'IO','British Indian Ocean Territory'),(32,'BN','Brunei Darussalam'),(33,'BG','Bulgaria'),(34,'BF','Burkina Faso'),(35,'BI','Burundi'),(36,'KH','Cambodia'),(37,'CM','Cameroon'),(38,'CA','Canada'),(39,'CV','Cape Verde'),(40,'KY','Cayman Islands'),(41,'CF','Central African Republic'),(42,'TD','Chad'),(43,'CL','Chile'),(44,'CN','China'),(45,'CX','Christmas Island'),(46,'CC','Cocos (Keeling) Islands'),(47,'CO','Colombia'),(48,'KM','Comoros'),(49,'CG','Congo'),(50,'CK','Cook Islands'),(51,'CR','Costa Rica'),(52,'HR','Croatia (Hrvatska)'),(53,'CU','Cuba'),(54,'CY','Cyprus'),(55,'CZ','Czech Republic'),(56,'DK','Denmark'),(57,'DJ','Djibouti'),(58,'DM','Dominica'),(59,'DO','Dominican Republic'),(60,'TP','East Timor'),(61,'EC','Ecuador'),(62,'EG','Egypt'),(63,'SV','El Salvador'),(64,'GQ','Equatorial Guinea'),(65,'ER','Eritrea'),(66,'EE','Estonia'),(67,'ET','Ethiopia'),(68,'FK','Falkland Islands (Malvinas)'),(69,'FO','Faroe Islands'),(70,'FJ','Fiji'),(71,'FI','Finland'),(72,'FR','France'),(73,'FX','France, Metropolitan'),(74,'GF','French Guiana'),(75,'PF','French Polynesia'),(76,'TF','French Southern Territories'),(77,'GA','Gabon'),(78,'GM','Gambia'),(79,'GE','Georgia'),(80,'DE','Germany'),(81,'GH','Ghana'),(82,'GI','Gibraltar'),(83,'GK','Guernsey'),(84,'GR','Greece'),(85,'GL','Greenland'),(86,'GD','Grenada'),(87,'GP','Guadeloupe'),(88,'GU','Guam'),(89,'GT','Guatemala'),(90,'GN','Guinea'),(91,'GW','Guinea-Bissau'),(92,'GY','Guyana'),(93,'HT','Haiti'),(94,'HM','Heard and Mc Donald Islands'),(95,'HN','Honduras'),(96,'HK','Hong Kong'),(97,'HU','Hungary'),(98,'IS','Iceland'),(99,'IN','India'),(100,'IM','Isle of Man'),(101,'ID','Indonesia'),(102,'IR','Iran (Islamic Republic of)'),(103,'IQ','Iraq'),(104,'IE','Ireland'),(105,'IL','Israel'),(106,'IT','Italy'),(107,'CI','Ivory Coast'),(108,'JE','Jersey'),(109,'JM','Jamaica'),(110,'JP','Japan'),(111,'JO','Jordan'),(112,'KZ','Kazakhstan'),(113,'KE','Kenya'),(114,'KI','Kiribati'),(115,'KP','Korea, Democratic People\'s Republic of'),(116,'KR','Korea, Republic of'),(117,'XK','Kosovo'),(118,'KW','Kuwait'),(119,'KG','Kyrgyzstan'),(120,'LA','Lao People\'s Democratic Republic'),(121,'LV','Latvia'),(122,'LB','Lebanon'),(123,'LS','Lesotho'),(124,'LR','Liberia'),(125,'LY','Libyan Arab Jamahiriya'),(126,'LI','Liechtenstein'),(127,'LT','Lithuania'),(128,'LU','Luxembourg'),(129,'MO','Macau'),(130,'MK','Macedonia'),(131,'MG','Madagascar'),(132,'MW','Malawi'),(133,'MY','Malaysia'),(134,'MV','Maldives'),(135,'ML','Mali'),(136,'MT','Malta'),(137,'MH','Marshall Islands'),(138,'MQ','Martinique'),(139,'MR','Mauritania'),(140,'MU','Mauritius'),(141,'TY','Mayotte'),(142,'MX','Mexico'),(143,'FM','Micronesia, Federated States of'),(144,'MD','Moldova, Republic of'),(145,'MC','Monaco'),(146,'MN','Mongolia'),(147,'ME','Montenegro'),(148,'MS','Montserrat'),(149,'MA','Morocco'),(150,'MZ','Mozambique'),(151,'MM','Myanmar'),(152,'NA','Namibia'),(153,'NR','Nauru'),(154,'NP','Nepal'),(155,'NL','Netherlands'),(156,'AN','Netherlands Antilles'),(157,'NC','New Caledonia'),(158,'NZ','New Zealand'),(159,'NI','Nicaragua'),(160,'NE','Niger'),(161,'NG','Nigeria'),(162,'NU','Niue'),(163,'NF','Norfolk Island'),(164,'MP','Northern Mariana Islands'),(165,'NO','Norway'),(166,'OM','Oman'),(167,'PK','Pakistan'),(168,'PW','Palau'),(169,'PS','Palestine'),(170,'PA','Panama'),(171,'PG','Papua New Guinea'),(172,'PY','Paraguay'),(173,'PE','Peru'),(174,'PH','Philippines'),(175,'PN','Pitcairn'),(176,'PL','Poland'),(177,'PT','Portugal'),(178,'PR','Puerto Rico'),(179,'QA','Qatar'),(180,'RE','Reunion'),(181,'RO','Romania'),(182,'RU','Russian Federation'),(183,'RW','Rwanda'),(184,'KN','Saint Kitts and Nevis'),(185,'LC','Saint Lucia'),(186,'VC','Saint Vincent and the Grenadines'),(187,'WS','Samoa'),(188,'SM','San Marino'),(189,'ST','Sao Tome and Principe'),(190,'SA','Saudi Arabia'),(191,'SN','Senegal'),(192,'RS','Serbia'),(193,'SC','Seychelles'),(194,'SL','Sierra Leone'),(195,'SG','Singapore'),(196,'SK','Slovakia'),(197,'SI','Slovenia'),(198,'SB','Solomon Islands'),(199,'SO','Somalia'),(200,'ZA','South Africa'),(201,'GS','South Georgia South Sandwich Islands'),(202,'ES','Spain'),(203,'LK','Sri Lanka'),(204,'SH','St. Helena'),(205,'PM','St. Pierre and Miquelon'),(206,'SD','Sudan'),(207,'SR','Suriname'),(208,'SJ','Svalbard and Jan Mayen Islands'),(209,'SZ','Swaziland'),(210,'SE','Sweden'),(211,'CH','Switzerland'),(212,'SY','Syrian Arab Republic'),(213,'TW','Taiwan'),(214,'TJ','Tajikistan'),(215,'TZ','Tanzania, United Republic of'),(216,'TH','Thailand'),(217,'TG','Togo'),(218,'TK','Tokelau'),(219,'TO','Tonga'),(220,'TT','Trinidad and Tobago'),(221,'TN','Tunisia'),(222,'TR','Turkey'),(223,'TM','Turkmenistan'),(224,'TC','Turks and Caicos Islands'),(225,'TV','Tuvalu'),(226,'UG','Uganda'),(227,'UA','Ukraine'),(228,'AE','United Arab Emirates'),(229,'GB','United Kingdom'),(230,'US','United States'),(231,'UM','United States minor outlying islands'),(232,'UY','Uruguay'),(233,'UZ','Uzbekistan'),(234,'VU','Vanuatu'),(235,'VA','Vatican City State'),(236,'VE','Venezuela'),(237,'VN','Vietnam'),(238,'VG','Virgin Islands (British)'),(239,'VI','Virgin Islands (U.S.)'),(240,'WF','Wallis and Futuna Islands'),(241,'EH','Western Sahara'),(242,'YE','Yemen'),(243,'ZR','Zaire'),(244,'ZM','Zambia'),(245,'ZW','Zimbabwe');

/*Table structure for table `tbl_xref_project_technology` */

DROP TABLE IF EXISTS `tbl_xref_project_technology`;

CREATE TABLE `tbl_xref_project_technology` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `technology_id` int(11) DEFAULT NULL,
  `value` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `technology_id` (`technology_id`),
  CONSTRAINT `tbl_xref_project_technology_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `tblprojectdetails` (`project_id`),
  CONSTRAINT `tbl_xref_project_technology_ibfk_2` FOREIGN KEY (`technology_id`) REFERENCES `tbltechnology` (`technology_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

/*Data for the table `tbl_xref_project_technology` */

insert  into `tbl_xref_project_technology`(`id`,`project_id`,`technology_id`,`value`) values (1,1,1,30),(2,1,2,20),(3,1,4,10),(4,1,7,40),(5,2,2,20),(6,2,1,50),(7,2,3,30),(12,4,4,80),(13,4,5,20),(14,5,4,20),(15,5,5,20),(16,5,6,40),(17,5,7,10),(18,6,4,45),(19,6,3,25),(20,6,2,30),(21,7,2,12),(22,7,7,8),(23,7,4,80),(24,8,5,45),(25,8,2,15),(26,8,4,30),(27,8,3,10),(28,3,3,70),(29,3,2,20),(30,3,1,10),(31,9,1,30),(32,9,2,20),(33,9,4,10),(34,9,7,40),(35,10,2,20),(36,10,1,50),(37,10,3,30),(38,11,4,80),(39,11,5,20),(40,12,4,20),(41,12,5,20),(42,12,6,40),(43,12,7,10),(44,13,4,45),(45,13,3,25),(46,13,2,30),(47,14,2,12),(48,14,7,8),(49,14,4,80),(50,15,5,45),(51,15,2,15),(52,15,4,30),(53,15,3,10);

/*Table structure for table `tbldomain` */

DROP TABLE IF EXISTS `tbldomain`;

CREATE TABLE `tbldomain` (
  `domain_id` int(11) NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`domain_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Data for the table `tbldomain` */

insert  into `tbldomain`(`domain_id`,`domain_name`) values (1,'FINANCE'),(2,'HEALTH'),(3,'LEAGLE'),(4,'Retail'),(5,'Banking'),(6,'Manufacturing'),(7,'Aerospace'),(8,'Law enforcement/military'),(9,'Public safety'),(10,'Education'),(11,'Entertainment');

/*Table structure for table `tblmembername` */

DROP TABLE IF EXISTS `tblmembername`;

CREATE TABLE `tblmembername` (
  `project_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `member_name` varchar(255) NOT NULL,
  `member_photo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `tblmembername_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `tblprojectdetails` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

/*Data for the table `tblmembername` */

insert  into `tblmembername`(`project_id`,`id`,`member_id`,`member_name`,`member_photo`) values (2,7,1,'Ankit Jain','Ankit_Jain.jpg'),(1,8,2,'Ankit Jani','Ankit_Jani.jpg'),(1,9,3,'Bhargav','Bhargav_Khatri.jpg'),(2,10,4,'Dhanraj','Dhanraj_Khodalilya.jpg'),(2,11,5,'Kedar','Kedar_Thakkar.jpg'),(1,12,6,'Kushal','Kushal_Shah.jpg'),(3,13,5,'Parth Ladani','Parth_Ladani.jpg'),(3,14,5,'Dushyant','Dushyant_Gohil.jpg'),(3,15,5,'Janmjay','Janmeyjayshingh_ Gohil.jpg'),(3,16,5,'Dharmesh','Dharmesh_Vaghela.jpg'),(4,17,5,'Kirtee','Kirtee_Chaudary.jpg'),(4,18,5,'Snehal','Snehal_Shah.jpg'),(4,19,4,'Dhanraj','Dhanraj_Khodalilya.jpg'),(4,20,5,'Kedar','Kedar_Thakkar.jpg'),(5,21,5,'Darshan','Darshan_Chaudasama.jpg'),(5,22,5,'Akash','Aakash_Patel.png'),(5,23,4,'Vimal','Vimal_Maru.jpg'),(5,24,5,'Nishant','Nishant_Chauhan.jpg'),(6,25,5,'Snehal','Snehal_Shah.jpg'),(6,26,5,'Kedar','Kedar_Thakkar.jpg'),(6,27,4,'Vimal','Vimal_Maru.jpg'),(6,28,5,'Bhargav','Kedar_Thakkar.jpg'),(7,29,5,'Parth Ladani','Parth_Ladani.jpg'),(7,30,5,'Dushyant','Dushyant_Gohil.jpg'),(7,31,5,'Snehal','Snehal_Shah.jpg'),(7,32,5,'Kedar','Kedar_Thakkar.jpg'),(8,33,5,'Kedar','Kedar_Thakkar.jpg'),(8,34,4,'Vimal','Vimal_Maru.jpg'),(8,35,2,'Ankit Jani','Ankit_Jani.jpg'),(8,36,3,'Bhargav','Bhargav_Khatri.jpg'),(9,37,5,'Akash','Aakash_Patel.png'),(9,38,4,'Vimal','Vimal_Maru.jpg'),(9,39,5,'Nishant','Nishant_Chauhan.jpg'),(10,40,5,'Snehal','Snehal_Shah.jpg'),(10,41,5,'Bhargav','Kedar_Thakkar.jpg'),(10,42,5,'Kedar','Kedar_Thakkar.jpg'),(10,43,4,'Vimal','Vimal_Maru.jpg'),(11,44,4,'Vimal','Vimal_Maru.jpg'),(11,45,5,'Nishant','Nishant_Chauhan.jpg'),(11,46,5,'Snehal','Snehal_Shah.jpg'),(11,47,5,'Kedar','Kedar_Thakkar.jpg'),(12,48,5,'Kirtee','Kirtee_Chaudary.jpg'),(12,49,5,'Snehal','Snehal_Shah.jpg'),(12,50,4,'Dhanraj','Dhanraj_Khodalilya.jpg'),(12,51,5,'Kedar','Kedar_Thakkar.jpg'),(13,52,5,'Parth Ladani','Parth_Ladani.jpg'),(13,53,5,'Dushyant','Dushyant_Gohil.jpg'),(13,54,5,'Snehal','Snehal_Shah.jpg'),(13,55,5,'Kedar','Kedar_Thakkar.jpg'),(14,56,4,'Vimal','Vimal_Maru.jpg'),(14,57,5,'Nishant','Nishant_Chauhan.jpg'),(14,58,5,'Snehal','Snehal_Shah.jpg'),(14,59,5,'Kedar','Kedar_Thakkar.jpg'),(15,60,5,'Snehal','Snehal_Shah.jpg'),(15,61,5,'Bhargav','Kedar_Thakkar.jpg'),(15,62,5,'Kedar','Kedar_Thakkar.jpg'),(15,63,4,'Vimal','Vimal_Maru.jpg');

/*Table structure for table `tblprojectdetails` */

DROP TABLE IF EXISTS `tblprojectdetails`;

CREATE TABLE `tblprojectdetails` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `project_status` varchar(255) NOT NULL,
  `project_duration` varchar(255) NOT NULL,
  `project_domain` varchar(255) NOT NULL,
  `project_complete_percent` varchar(255) NOT NULL,
  `project_inprogress_percent` varchar(255) NOT NULL,
  `comapny_id` int(11) DEFAULT NULL,
  `domain_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `hours_spent` double DEFAULT NULL,
  PRIMARY KEY (`project_id`),
  KEY `comapny_id` (`comapny_id`),
  KEY `domain_id` (`domain_id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `tblprojectdetails_ibfk_1` FOREIGN KEY (`comapny_id`) REFERENCES `tbl_company` (`company_id`),
  CONSTRAINT `tblprojectdetails_ibfk_2` FOREIGN KEY (`domain_id`) REFERENCES `tbldomain` (`domain_id`),
  CONSTRAINT `tblprojectdetails_ibfk_3` FOREIGN KEY (`country_id`) REFERENCES `tbl_country` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

/*Data for the table `tblprojectdetails` */

insert  into `tblprojectdetails`(`project_id`,`project_name`,`client_name`,`project_status`,`project_duration`,`project_domain`,`project_complete_percent`,`project_inprogress_percent`,`comapny_id`,`domain_id`,`country_id`,`hours_spent`) values (1,'INFORMATION RADIATOR','Mr.Smith','running','one month','Finances','50','25',1,1,1,190),(2,'Inventory Management','Mr.Tonny','ongoing','two month','domain_234','60','30',1,1,2,380),(3,'Stock management','Mr.Jignesh shah','30%','30 days','domain_345','25','50',1,8,3,190),(4,'Mall management','MR.Choi','50%','2 Month','domain_456','90','2',1,1,4,380),(5,'Canopus EpaySuite','Mr.Williams','70%','2.5 year','ss','70','25',1,5,161,4400),(6,'Axis Banking','Axis Bank','40%','1.5 year','sds','40','60',1,5,99,3000),(7,'Zydus Hospital management','Zydus Hospital','90%','1.9 Year','DOM','90','10',1,2,99,2900),(8,'Sanjivani Health care','Sanjivani','35%','1.8 year','DOM','80','20',1,2,99,2700),(9,'Fishbowl Manufacturing','Mr.Brown','75%','1.3 Year','DOM','38','62',1,6,22,3200),(10,'EWIS','Mr.Binaya','100%','1 year','df','100%','0',1,6,65,2200),(11,'Rocket Engine Transient Simulations','ISRO','40%','3 year','DOM','40','60',1,7,99,4500),(12,'DUCS','US Government','65%','4 year','DOM','65','35',1,8,230,8448),(13,'Flex','Mr.Thomas','62%','2 year','DOM','62','38',1,9,30,4000),(14,'GTU management ','GTU','90%','1 year','DOm','90','10',1,10,99,2200),(15,'Gaana','gaana.com','85%','0.6 year','DOM','85','15',1,11,99,1100);

/*Table structure for table `tbltechnology` */

DROP TABLE IF EXISTS `tbltechnology`;

CREATE TABLE `tbltechnology` (
  `technology_id` int(11) NOT NULL AUTO_INCREMENT,
  `technology_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`technology_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `tbltechnology` */

insert  into `tbltechnology`(`technology_id`,`technology_name`) values (1,'JAVA'),(2,'HTML'),(3,'PHP'),(4,'SPRING'),(5,'ANGULAR'),(6,'.NET'),(7,'REACT JS'),(8,'HIBERNATE');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
