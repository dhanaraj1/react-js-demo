package com.rest.bean;

public class CategoryColumnChart {
	private String label;
	private boolean stepSkipped;
	private boolean  appliedSmartLabel;
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public boolean isStepSkipped() {
		return stepSkipped;
	}
	public void setStepSkipped(boolean stepSkipped) {
		this.stepSkipped = stepSkipped;
	}
	public boolean isAppliedSmartLabel() {
		return appliedSmartLabel;
	}
	public void setAppliedSmartLabel(boolean appliedSmartLabel) {
		this.appliedSmartLabel = appliedSmartLabel;
	}
	
	
}
