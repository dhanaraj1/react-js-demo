package com.rest.bean;

public class Projectdt {

	private int projectId;
	private String projectName;
	private String clientName;
	private String project_status;
	private String project_duration;
	private String project_domain;
	private String project_complete_percent;
	private String project_inprogress_percent;
	private double hourSpent;
	private String counrty;
	private int benifite;	
	public Projectdt(){}


	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}


	public String getProject_status() {
		return project_status;
	}

	public void setProject_status(String project_status) {
		this.project_status = project_status;
	}

	public String getProject_duration() {
		return project_duration;
	}

	public void setProject_duration(String project_duration) {
		this.project_duration = project_duration;
	}
	
	public String getProject_domain() {
		return project_domain;
	}

	public void setProject_domain(String project_domain) {
		this.project_domain = project_domain;
	}
	
	public String getProject_complete_percent() {
		return project_complete_percent;
	}

	public void setProject_complete_percent(String project_complete_percent) {
		this.project_complete_percent = project_complete_percent;
	}

	public String getProject_inprogress_percent() {
		return project_inprogress_percent;
	}

	public void setProject_inprogress_percent(String project_inprogress_percent) {
		this.project_inprogress_percent = project_inprogress_percent;
	}


	public double getHourSpent() {
		return hourSpent;
	}


	public void setHourSpent(double hourSpent) {
		this.hourSpent = hourSpent;
	}


	public String getCounrty() {
		return counrty;
	}


	public void setCounrty(String counrty) {
		this.counrty = counrty;
	}


	public int getBenifite() {
		return benifite;
	}


	public void setBenifite(int benifite) {
		this.benifite = benifite;
	}

}