package com.rest.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.rest.bean.CategoryColumnChart;
import com.rest.bean.Memberdt;
import com.rest.bean.Projectdt;
import com.rest.bean.Technologydt;

@Repository("projectdtDao")
public class ProjectdtDaoImpl implements ProjectdtDao {
	
	private static final String Q_CONPANY_TECH = "SELECT t.technology_name,t.technology_id, ((sum(xref.value)/(select sum(re.value) from "
			+ " tbl_xref_project_technology re ))*100) as value from tblprojectdetails p inner join tbl_xref_project_technology xref on "
			+ "xref.project_id = p.project_id inner join tbltechnology t on t.technology_id = xref.technology_id where p.comapny_id=? group "
			+ "by t.technology_name";
	private static final String Q_PROJECT_BY_ID = "SELECT p.*,d.domain_name,c.country_name FROM tblprojectdetails p left join tbldomain d on "
			+ "d.domain_id=p.domain_id left join tbl_country c on c.id=p.country_id WHERE p.project_Id = ?";
	
	private static final String Q_PROJECT_COUNT_PER_DOMAIN_BY_TECH="select count(distinct p.project_id)as value,d.domain_name as technology_name,d.domain_id as technology_id from "
			+ "tbl_xref_project_technology t  inner join tblprojectdetails p on p.project_id=t.project_id inner join tbldomain d "
			+ "on d.domain_id = p.domain_id where t.technology_id = ? group by p.domain_id ";
	
	private JdbcTemplate jdbcTemplate;

	 @Autowired
	 public void setDataSource(DataSource dataSource) {
	  this.jdbcTemplate = new JdbcTemplate(dataSource);
	 }

	public List<Projectdt> getProjectAllDetails() {
		List<Projectdt> projectdt = null;
		
		try {
			projectdt = jdbcTemplate.query("SELECT * FROM tblprojectdetails",new BeanPropertyRowMapper<Projectdt>(Projectdt.class));   
			} catch (DataAccessException e) {
			  e.printStackTrace();
			}
		return projectdt;
	}

	
	public Projectdt getProjectAllDetailsById(int projectId) {
		Projectdt projectdt = null;
		  try {
			  projectdt = jdbcTemplate.queryForObject(Q_PROJECT_BY_ID,
		     new Object[] { projectId }, new ProjectMapper());
		  } catch (DataAccessException e) {
		   e.printStackTrace();
		  }
		  return projectdt;
	}

	
	public List<Memberdt> getAllMembersName() {
		List<Memberdt> memberdt = null;
		
		try {
			memberdt = jdbcTemplate.query("SELECT * FROM tblmembername",new BeanPropertyRowMapper<Memberdt>(Memberdt.class));   
			} catch (DataAccessException e) {
			  e.printStackTrace();
			}
		return memberdt;
	}

	
	public List<Memberdt> getMembersNameById(int projectId) {
		List<Memberdt> memberdt = null;
		  try {
			  memberdt = jdbcTemplate.query("SELECT * FROM tblmembername WHERE project_Id = ?",
		     new Object[] { projectId }, new BeanPropertyRowMapper<Memberdt>(Memberdt.class));
		  } catch (DataAccessException e) {
		   e.printStackTrace();
		  }
		  
		  return  memberdt;
	}

//for technology
	
	public List<Technologydt> getAllTechnologyName() {
		List<Technologydt> technologydt = null;
		
		try {
			technologydt = jdbcTemplate.query("SELECT * FROM tblTechnology",new TechnologyMapper());   
			} catch (DataAccessException e) {
			  e.printStackTrace();
			}
		return technologydt;
	}


	public List<Technologydt> getTechnologyNameById(int comapnyId) {
		List<Technologydt> technologydt = null;
		  try {
			  technologydt = jdbcTemplate.query(this.Q_CONPANY_TECH,
		     new Object[] { comapnyId }, new TechnologyMapper());
		  } catch (DataAccessException e) {
		   e.printStackTrace();
		  }
		  
		  return  technologydt;
	}
	
	@Override
	public List<Technologydt> getDomainChartDataByTechnologyId(int technologyId) {
		List<Technologydt> technologydt = null;
		  try {
			  technologydt = jdbcTemplate.query(this.Q_PROJECT_COUNT_PER_DOMAIN_BY_TECH,
		     new Object[] { technologyId }, new TechnologyMapper());
		  } catch (DataAccessException e) {
		   e.printStackTrace();
		  }
		  
		  return  technologydt;
	}
	
	 class TechnologyMapper implements RowMapper<Technologydt>{

		@Override
		public Technologydt mapRow(ResultSet rs, int arg1) throws SQLException {
			Technologydt tc= new Technologydt();
			tc.setLabel(rs.getString("technology_name"));
			tc.setValue(rs.getDouble("value"));
			tc.setTechnologyId(rs.getInt("technology_id"));
			
			return tc;
		}
		
	}
	 
	 class ProjectMapper implements RowMapper<Projectdt>{

			@Override
			public Projectdt mapRow(ResultSet rs, int arg1) throws SQLException {
				Projectdt tc= new Projectdt();
				tc.setBenifite(10);
				tc.setClientName(rs.getString("client_name"));
				tc.setCounrty(rs.getString("country_name"));
				tc.setHourSpent(rs.getDouble("hours_spent"));
				tc.setProject_complete_percent(rs.getString("project_complete_percent"));
				tc.setProject_domain(rs.getString("domain_name"));
				tc.setProject_inprogress_percent(rs.getString("project_inprogress_percent"));
				tc.setProject_status(rs.getString("project_status"));
				tc.setProjectId(rs.getInt("project_id"));
				tc.setProjectName(rs.getString("project_name"));
				
				return tc;
			}
			
		}

	@Override
	public List<CategoryColumnChart> getProjectsByDomain(int id) {
		List<CategoryColumnChart> listData = new ArrayList<CategoryColumnChart>();
		listData =jdbcTemplate.query("select p.project_name from  tblprojectdetails p where p.domain_id = ?",new Object[]{id}, new RowMapper<CategoryColumnChart>(){

			@Override
			public CategoryColumnChart mapRow(ResultSet rs, int arg1) throws SQLException {
				CategoryColumnChart cdata= new CategoryColumnChart();
				cdata.setLabel(rs.getString("project_name"));
				return cdata;
			}
			
		});
		
		return listData;
	}

	
}