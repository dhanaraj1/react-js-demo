package com.rest.dao;

import java.util.List;

import com.rest.bean.CategoryColumnChart;
import com.rest.bean.Memberdt;
import com.rest.bean.Projectdt;
import com.rest.bean.Technologydt;

public interface ProjectdtDao {

	public List<Projectdt> getProjectAllDetails();

	public Projectdt getProjectAllDetailsById(int projectId);

	public List<Memberdt> getAllMembersName();
	
	public List<Memberdt> getMembersNameById(int projectId);
	
	public List<Technologydt> getAllTechnologyName();
	
	public List<Technologydt> getTechnologyNameById(int companyId);

	public List<Technologydt> getDomainChartDataByTechnologyId(int technologyId);

	public List<CategoryColumnChart> getProjectsByDomain(int id);
	
}
