package com.rest.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/company")
public class ComapnyController {

	@RequestMapping(value = { "/clients" })
	public List<String> getClients(@RequestParam("id") int id, HttpServletRequest request) {

		final List<String> clients = new ArrayList<>();
		clients.add("A");
		clients.add("B");
		clients.add("C");
		clients.add("D");
		clients.add("E");
		clients.add("F");

		return clients;

	}

	@RequestMapping(value = { "/test" })
	public String getdata(HttpServletRequest request) {

		request.getParameterMap().get("data")[0] = "update";

		// parameterMap.put("data", s);
		String parameter = request.getParameterValues("data")[0];
		parameter = "update";

		System.out.println("only not to remove ==>" + parameter);
		// System.out.println(request.getParameterValues("data")[0]);
		return request.getParameter("data");

	}

	@RequestMapping(value = { "/download" }, produces = "application/pdf")

	public void download(HttpServletResponse response) throws IOException {

		System.out.println("Calling Download:- ");
		final ClassPathResource pdfFile = new ClassPathResource("/pdf/tst.pdf");
		final InputStream is = pdfFile.getInputStream();
		response.addHeader("Content-disposition", "attachment;filename=profile.pdf");
		response.setContentType("txt/plain");
		org.apache.commons.io.IOUtils.copy(is, response.getOutputStream());
		response.flushBuffer();

	}
}
