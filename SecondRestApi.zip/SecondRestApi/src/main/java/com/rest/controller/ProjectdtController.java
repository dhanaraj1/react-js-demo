package com.rest.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.rest.bean.Memberdt;
import com.rest.bean.PieChartTechnology;
import com.rest.bean.Projectdt;
import com.rest.bean.Technologydt;
import com.rest.service.ProjectdtService;

@RestController
public class ProjectdtController {

	@Autowired
	private ProjectdtService projectdtService;
	ObjectMapper mapper = new ObjectMapper();

	@RequestMapping(value = "/ProjectDetails", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Projectdt>> employees() {

		final HttpHeaders headers = new HttpHeaders();
		final List<Projectdt> projectdt = projectdtService.getProjectAllDetails();

		if (projectdt == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		headers.add("Number Of Records Found", String.valueOf(projectdt.size()));
		return new ResponseEntity<>(projectdt, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/ProjectDetails/{id}", method = RequestMethod.GET)
	public ResponseEntity<Projectdt> getEmployee(@PathVariable("id") int projectId) {

		final Projectdt projectdt = projectdtService.getProjectAllDetailsById(projectId);
		if (projectdt == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(projectdt, HttpStatus.OK);
	}

	// for member

	@RequestMapping(value = "/ProjectDetails/TeamMembers", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Memberdt>> employeesName() {

		final HttpHeaders headers = new HttpHeaders();
		final List<Memberdt> memberdt = projectdtService.getAllMembersName();

		if (memberdt == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		headers.add("Number Of Records Found", String.valueOf(memberdt.size()));
		return new ResponseEntity<>(memberdt, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/ProjectDetails/TeamMembers/{id}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Memberdt>> getEmployeeName(@PathVariable("id") int projectId) {

		final HttpHeaders headers = new HttpHeaders();
		final List<Memberdt> memberdt = projectdtService.getMembersNameById(projectId);
		if (memberdt == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		headers.add("Number Of Records Found", String.valueOf(memberdt.size()));
		return new ResponseEntity<>(memberdt, headers, HttpStatus.OK);
	}

	// for Technology

	@RequestMapping(value = "/ProjectDetails/Technology", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Technologydt>> employeesTechnology() {

		final HttpHeaders headers = new HttpHeaders();
		final List<Technologydt> technologydt = projectdtService.getAllTechnologyName();

		if (technologydt == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		headers.add("Number Of Records Found", String.valueOf(technologydt.size()));
		return new ResponseEntity<>(technologydt, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/ProjectDetails/Technology/{id}", method = RequestMethod.GET, produces = "application/json")
	public Object getEmployeTechnology(@PathVariable("id") int companyId) {

		final HttpHeaders headers = new HttpHeaders();
		final Map<String, Object> data = new HashMap<>();
		final List<Technologydt> technologydt = projectdtService.getTechnologyNameById(companyId);
		if (technologydt == null) {
			data.put("technologies", technologydt);
			return new ResponseEntity<>(data, headers, HttpStatus.NOT_FOUND);
		}
		final List<Object> linkeddata = new ArrayList<>();
		for (final Technologydt technology : technologydt) {
			technology.setLink("newchart-xml-" + technology.getLabel());
			final Map<String, Object> chartParent = new HashMap<>();
			chartParent.put("id", technology.getLabel());
			chartParent.put("linkedchart", getDomainChartbyTechnology(technology.getTechnologyId(), companyId));

			linkeddata.add(chartParent);

		}
		data.put("technologies", technologydt);
		data.put("linkeddata", linkeddata);

		return new ResponseEntity<>(data, headers, HttpStatus.OK);
	}

	private Object getDomainChartbyTechnology(int technologyId, int companyId) {

		final Map<String, Object> chartParent = new HashMap<>();
		final PieChartTechnology chart = new PieChartTechnology();
		chart.setStartingangle("120");
		chart.setShowlabels("0");
		chart.setShowlegend("1");
		chart.setEnablemultislicing("0");
		chart.setSlicingdistance("15");
		chart.setShowpercentvalues("0");
		chart.setShowpercentintooltip("0");
		chart.setTheme("ocean");
		chart.setDecimals("0");
		chartParent.put("chart", chart);
		chart.setCaption("Domains");
		List<Technologydt> domainData = new ArrayList<>();

		domainData = projectdtService.getDomainChartDataByTechnologyId(technologyId);

		for (final Technologydt technologydt : domainData) {
			technologydt.setLink("newchart-xml-pro" + technologydt.getLabel());
		}

		chartParent.put("data", domainData);
		List<Object> linkdata = null;
		new HashMap<String, Object>();
		for (final Technologydt technologydt : domainData) {
			linkdata = new ArrayList<>();
			final InputStream inJson = ProjectdtController.class.getResourceAsStream("projectComaprision.json");
			JsonNode jsonpObject;
			try {
				jsonpObject = new ObjectMapper().readValue(inJson, JsonNode.class);
				((ObjectNode) jsonpObject).put("id", "pro" + technologydt.getLabel());
				final JsonNode categoriesNode = jsonpObject.get("linkedchart").get("categories").get(0).get("category");
				((ArrayNode) categoriesNode).removeAll();

				final JsonNode jsonNode2 = mapper.convertValue(projectdtService.getProjectsByDomain(technologydt.getTechnologyId()), JsonNode.class);
				((ArrayNode) categoriesNode).addAll((ArrayNode) jsonNode2);

				linkdata.add(jsonpObject);
				chartParent.put("linkeddata", linkdata);
			} catch (final JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (final JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (final IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return chartParent;
	}

	@RequestMapping(value = "/images", method = RequestMethod.GET)
	public void immage(HttpServletRequest request, HttpServletResponse response,
			/* @PathVariable(value = "photoname")String filename */ @RequestParam(value = "photoname") String filename) {

		try {

			response.setContentType("text/html;charset=UTF-8");

			final File file = new File("C://var/images/", filename);
			response.setHeader("Content-Type", "image/JPEG");
			response.setHeader("Content-Length", String.valueOf(file.length()));
			response.setHeader("Content-Disposition", "inline; filename=\"" + filename + "\"");
			Files.copy(file.toPath(), response.getOutputStream());
		} catch (final IOException ex) {
			ex.printStackTrace();
		}

	}

	@RequestMapping(value = "/getProjectDone", method = RequestMethod.GET)
	public Map<String, String> getProjectDone() {

		final Map<String, String> countMap = new HashMap<>();
		countMap.put("count", "80");

		return countMap;
	}

	@RequestMapping(value = "/getTotalClients", method = RequestMethod.GET)
	public Map<String, String> getTotalClients() {

		final Map<String, String> countMap = new HashMap<>();
		countMap.put("count", "65");

		return countMap;
	}

	@RequestMapping(value = "/ProjectDetails/getProjectActivityChartData/{id}", method = RequestMethod.GET)
	public ArrayList<Map<String, String>> getProjectActivityChartData(@PathVariable("id") int projectId) {

		final Projectdt projectdt = projectdtService.getProjectAllDetailsById(projectId);

		final Map<String, String> completedMap = new HashMap<>();
		completedMap.put("label", "completed");
		completedMap.put("value", projectdt.getProject_complete_percent());

		final Map<String, String> inprogressMap = new HashMap<>();
		inprogressMap.put("label", "inprogress");
		inprogressMap.put("value", projectdt.getProject_inprogress_percent());

		final Map<String, String> pendingMap = new HashMap<>();
		pendingMap.put("label", "pending");
		pendingMap.put("value", projectdt.getProject_inprogress_percent());

		final ArrayList<Map<String, String>> test = new ArrayList<>();
		test.add(completedMap);
		test.add(inprogressMap);
		test.add(pendingMap);

		return test;
	}
}