package com.rest.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.rest.bean.TestMap;

@Controller
public class HomeController {
	@RequestMapping("/")
	public ModelAndView home(ModelAndView modelAndView){
		modelAndView.setViewName("index");
		
		return modelAndView;
	}
	
	@RequestMapping("/test")
	public ModelAndView test(ModelAndView modelAndView,@ModelAttribute("testMap") TestMap data){
		modelAndView.setViewName("index");
		System.out.println(data.getMap().size());
		return modelAndView;
	}


}
