package com.rest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.bean.CategoryColumnChart;
import com.rest.bean.Memberdt;
import com.rest.bean.Projectdt;
import com.rest.bean.Technologydt;
import com.rest.dao.ProjectdtDao;


@Service("projectdtService")
public class ProjectdtServiceImpl implements ProjectdtService {

	@Autowired
	private ProjectdtDao projectdtDao;
	
	
	public List<Projectdt> getProjectAllDetails() {
		List<Projectdt> projectdt = projectdtDao.getProjectAllDetails();		
		return projectdt;
	}
	
	
	
	public Projectdt getProjectAllDetailsById(int projectId) {
		Projectdt projectdt = projectdtDao.getProjectAllDetailsById(projectId);
		return projectdt;
	}


	public List<Memberdt> getAllMembersName() {
		List<Memberdt> memberdt = projectdtDao.getAllMembersName();
		return memberdt;
	}

	public List<Memberdt> getMembersNameById(int projectId) {
		List<Memberdt> memberdt = projectdtDao.getMembersNameById(projectId);
		return memberdt;
	}


	public List<Technologydt> getAllTechnologyName() {
		List<Technologydt> technologydt = projectdtDao.getAllTechnologyName();
		return technologydt;
	}


	public List<Technologydt> getTechnologyNameById(int comapnyId) {
		List<Technologydt> technologydt = projectdtDao.getTechnologyNameById(comapnyId);
		return technologydt;
	}



	@Override
	public List<Technologydt> getDomainChartDataByTechnologyId(int technologyId) {
		// TODO Auto-generated method stub
		return projectdtDao.getDomainChartDataByTechnologyId(technologyId);
	}



	@Override
	public List<CategoryColumnChart> getProjectsByDomain(int id) {
		
		return projectdtDao.getProjectsByDomain(id);
	}

}
