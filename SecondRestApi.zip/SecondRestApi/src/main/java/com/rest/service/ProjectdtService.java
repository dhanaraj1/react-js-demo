package com.rest.service;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.rest.bean.CategoryColumnChart;
import com.rest.bean.Memberdt;
import com.rest.bean.Projectdt;
import com.rest.bean.Technologydt;

public interface ProjectdtService {

	public List<Projectdt> getProjectAllDetails();

	public Projectdt getProjectAllDetailsById(int projectId);
	
	public List<Memberdt> getAllMembersName();
	
	public List<Memberdt> getMembersNameById(int projectId);
	
	public List<Technologydt> getAllTechnologyName();
	
	public List<Technologydt> getTechnologyNameById(int comapnyId);

	public List<Technologydt> getDomainChartDataByTechnologyId(int technologyId);

	public List<CategoryColumnChart> getProjectsByDomain(int id);
}
