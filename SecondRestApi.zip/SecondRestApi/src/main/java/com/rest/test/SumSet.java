/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.rest.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The <code>SumSet</code> class is responsible for in <b>CCM</b>.
 * 
 * @author Manish
 */
public class SumSet {
	private static Set<Double> Added = new HashSet<Double>();

	static void sum_up_recursive(ArrayList<Double> numbers, int target, ArrayList<Double> partial) {
		// numbers.removeAll(partial);

		int s = 0;
		for (Double x : partial)
			s += x;
		if (s == target) {
			System.out.println("********************************************************");
			System.out.println("sum(" + Arrays.toString(partial.toArray()) + ")=" + target);
			Added.addAll(partial);
			System.out.println("********************************************************");
			// System.out.println("num
			// ("+Arrays.toString(numbers.toArray())+")");
			// numbers.removeAll(partial);
		}
		// numbers.remove(s);

		if (s >= target) {

			return;
		}
		for (int i = 0; i < numbers.size(); i++) {
			ArrayList<Double> remaining = new ArrayList<Double>();
			Double n = numbers.get(i);
			for (int j = i + 1; j < numbers.size(); j++)
				if (!Added.contains(numbers.get(j)))
					remaining.add(numbers.get(j));

			ArrayList<Double> partial_rec = new ArrayList<Double>(partial);
			if (!Added.contains(n))
				partial_rec.add(n);
			partial.removeAll(Added);
			remaining.remove(n);
			sum_up_recursive(remaining, target, partial_rec);
		}
	}

	static void sum_up(ArrayList<Double> numbers, int target) {
		sum_up_recursive(numbers, target, new ArrayList<Double>());
	}

	public static void main(String args[]) {
		Double[] numbers = { 2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0,18.0 };
		int target = 18;
		sum_up(new ArrayList<Double>(Arrays.asList(numbers)), target);
	}
}
