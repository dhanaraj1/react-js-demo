package com.rest.test;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Test {
		public static void main(String[] args) {
			String s="B1000025,129.85,2457,129.90,1287";
			
			System.out.println(s.substring(s.indexOf("B")+1).split(",")[1]);
    }
}
